#!/bin/bash
java -jar BackEnd-Attendance-0.0.1-SNAPSHOT.jar